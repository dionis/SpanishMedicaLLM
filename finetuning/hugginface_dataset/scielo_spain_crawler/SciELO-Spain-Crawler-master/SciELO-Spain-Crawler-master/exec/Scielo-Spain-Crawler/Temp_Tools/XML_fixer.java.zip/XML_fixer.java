package Temp_Tools;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

public class XML_fixer {

	public static void main(String[] args) throws IOException 
	{
		// Recibe el archivo XML como parametro.
		String file = args[0];
		
		// Guarda las lineas del archivo XML en una lista.
		List<String> lines = new ArrayList<String>();
		
		/*
		 *  Lee el archivo XML como si fuera un archivo de texto corriente linea por linea.
		 *  
		 *  El formato que se ha utilizado en este caso es ISO_8859_1, podeis sustituirlo a vuestra necesidad, como UTF_8.
		 */
		BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(file), 
				StandardCharsets.UTF_8));
		String line = "";
		while ((line = reader.readLine()) != null)
		{
			// El proceso de sustitucion se lleva a cabo si no hay CDATA en la linea.
			if (!line.contains("CDATA"))
			{
				// Si se detecta "&" se sustituye por "&amp;".
				if (line.contains(" & "))
				{
					line = line.replaceAll(" & ", " &amp; ");
				}
				
				// Si se detecta "&acute" lo sustituye por una apostrofe.
				if (line.contains("&acute;"))
				{
					line = line.replaceAll("&acute;", "'");
				}
				
				// Si se detecta "&ap" simplemente quita el ampersand. No se que indica &ap exactamente
				if (line.contains(" &ap "))
				{
					line = line.replaceAll("&ap", "ap");
				}
				
				// Si se detecta "&shy;", se sustituye por una raya corriente "-".
				if (line.contains("&shy;"))
				{
					line = line.replaceAll("&shy;", "-");
				}
				
				// Podeis añadir a continuacion otros casos que hayais detectado y necesiteis corregir:
				// if (line.contains(...) {}
			}
			
			// Se añade cada linea del archivo (originales y modificados) a la lista de lineas. 
			lines.add(line);
		}
		reader.close();
		
		// Se le da un nombre al archivo de salida. Si el original es "archivo.xml", el modificado se llamara "archivo.fixed.xml".
		String outputFile = file.replace(".xml", ".fixed.xml");
		
		// Se crea el archivo de salida y se escribe cada linea.
		OutputStreamWriter writer = new OutputStreamWriter(new FileOutputStream(outputFile), 
				StandardCharsets.UTF_8);
		for (int k = 0; k < lines.size(); k++)
		{
			String newLine = lines.get(k);
			writer.write(newLine + "\n"); 
		}
		writer.close();
	}

}
